# MAG7 Trade Strategy Playbook

## 1. MAG7 Key Level Alert
- Tracks 3-day high/low for top 7 stocks
- Sends alert when touched
- Manually trade option contracts with 2-contract setup

## 2. School Run (Hougaard Style)
- Trade DAX or FTSE open 2–5 min after cash open
- Watch for breakouts of early range
- 3-bar pattern or impulse candle triggers entry

## 3. NY Session High/Low Strategy
- Wait for price to touch previous day high/low
- Look for power candle or rejection wick
- Use measured move or VWAP reversion

## 4. Signal Types
- Entry
- Exit
- Confirmation
- Anomaly (optional AI/LLM-enhanced future layer)