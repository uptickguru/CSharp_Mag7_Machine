# MAG7 Deployment & Hosting Plan

## 🏗 Local Dev
- Run from `Program.cs`
- Log and test with local TimescaleDB
- Use appsettings.json for secrets/config

## ☁️ Cloud Migration (Planned)
- Target AWS EC2 + RDS (PostgreSQL/Timescale)
- Separate DB, Web API, and Trading Agent components
- Optional: move tickstream to AWS Kinesis → DB

## 🔒 Security & Auth
- Store secrets in environment variables
- Future: encrypt config at rest

## 💡 Roadmap
- Add containerized support (Docker)
- Add web dashboard for signals & journal
- Integrate Trade Execution routing (manual first, auto optional)