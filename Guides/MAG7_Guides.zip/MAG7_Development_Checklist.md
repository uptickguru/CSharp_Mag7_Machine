# MAG7 Development Checklist

## ✅ Phase 1: Infrastructure
- [x] Setup C# project and solution
- [x] Create folder structure
- [x] Setup TimescaleDB (self-hosted)
- [x] Create hypertables

## 🔁 Phase 2: Broker + DB Integration
- [ ] Add TastyAuthService.cs
- [ ] Add TastyStreamClient.cs
- [ ] Add TimescaleDbWriter.cs
- [ ] Write test data to DB

## 🔁 Phase 3: Strategy Core
- [ ] Build MAG7 signal logic
- [ ] Build futures opening range logic
- [ ] Create strategy plug-in interface

## 🧪 Phase 4: Testing + Validation
- [ ] Simulate data streams
- [ ] Validate tick insertions
- [ ] Run signal checks against live data

## 🚀 Phase 5: Deployment
- [ ] Build deployable .exe
- [ ] Plan cloud migration to AWS