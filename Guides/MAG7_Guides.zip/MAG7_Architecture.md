# MAG7 System Architecture

## Overview
The MAG7 C# Trading System is a modular, DI-enabled real-time trading platform supporting:
- TastyTrade and Alpaca broker APIs
- Futures and options trade logic
- TimescaleDB for streaming storage
- Strategy plug-ins and real-time alerts

## Layered Architecture
1. **Core**: Strategy interfaces, service logic, signal detection
2. **Brokers**: TastyTrade WebSocket + REST integration
3. **Data**: TimescaleDB persistence and readback
4. **Main**: App host (console or service) wired with DI

## Broker Streaming
- Uses Websocket.Client to subscribe to quote feeds
- Authenticated using session token from REST
- Tick data streamed into TimescaleDB

## DB Engine
- PostgreSQL + TimescaleDB extension
- Tables: `mag7_ticks`, `mag7_ohlcv_1m`, `mag7_signals`

## Extensibility
- Add strategies in `core/strategies/`
- Add broker connectors in `brokers/{name}`