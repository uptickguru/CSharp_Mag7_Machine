# MAG7 Broker Integration Notes

## TastyTrade API

### Authentication
- POST /sessions
- Returns `session_token`
- Used in Authorization: Bearer headers

### WebSocket Stream
- wss://streamer.tastyworks.com
- Requires:
  ```json
  { "action": "authenticate", "token": "<session_token>" }
  ```
- Subscribe example:
  ```json
  { "action": "subscribe", "quotes": ["MESU5"] }
  ```

## Symbols of Interest
- MES, ES, NQ, RTY
- AAPL, AMZN, MSFT, NVDA, META, TSLA, GOOG